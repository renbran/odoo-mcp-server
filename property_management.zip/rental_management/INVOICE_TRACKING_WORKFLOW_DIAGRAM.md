# 📊 Invoice Tracking Workflow Diagram

## Complete Sales Contract Workflow with Invoice Tracking

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         PROPERTY SALES WORKFLOW                          │
│                    with Enhanced Invoice Tracking v3.5.0                 │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 1: CONTRACT CREATION (Draft Stage)                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  [Create Sales Contract]                                                │
│          │                                                               │
│          ├─→ Select Property (stage = 'sale')                          │
│          ├─→ Add Customer Details                                       │
│          ├─→ Configure Pricing                                          │
│          ├─→ Set Booking Amount (% or fixed)                           │
│          ├─→ Set DLD Fee (4% or fixed)                                 │
│          └─→ Set Admin Fee (fixed)                                      │
│                                                                          │
│  [Save Contract] → Stage: "Draft - Awaiting Booking Payment"           │
│          │                                                               │
│          ▼                                                               │
│  ┌───────────────────────────────────────────┐                         │
│  │  📋 Create Booking Invoices Button        │                         │
│  │  (Generates 3 invoices automatically)     │                         │
│  └───────────────────────────────────────────┘                         │
│          │                                                               │
│          ▼                                                               │
│  ┌───────────────────────────────────────────┐                         │
│  │ ✓ Booking Invoice (immediate)             │                         │
│  │ ✓ DLD Fee Invoice (due in 30 days)        │                         │
│  │ ✓ Admin Fee Invoice (due in 30 days)      │                         │
│  └───────────────────────────────────────────┘                         │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 2: PAYMENT MONITORING (Draft Stage)                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────┐       │
│  │  ⏳ Awaiting Booking Payments Alert Box                     │       │
│  │  ┌──────────────────────────────────────────────────────┐  │       │
│  │  │ Progress: [████░░░░░░] 33%                            │  │       │
│  │  │                                                        │  │       │
│  │  │ • Booking Payment: ✓ Paid (50,000 AED)               │  │       │
│  │  │ • DLD Fee:        ✗ Pending (80,000 AED)            │  │       │
│  │  │ • Admin Fee:      ✗ Pending (20,000 AED)            │  │       │
│  │  └──────────────────────────────────────────────────────┘  │       │
│  └─────────────────────────────────────────────────────────────┘       │
│                                                                          │
│  Smart Buttons Display:                                                 │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐            │
│  │📋 Booking│📅 Install│📄 All    │📚 Created│✅ Paid   │            │
│  │    (3)   │   (0)    │  (3)     │   (1)    │   (1)    │            │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘            │
│                                                                          │
│  User Actions:                                                          │
│  1. Create accounting invoices (account.move)                          │
│  2. Register payments in Accounting                                    │
│  3. System auto-updates payment status                                 │
│                                                                          │
│  Progress Updates:                                                      │
│  33% → 67% → 100% ✓                                                    │
│                                                                          │
│          When all paid (100%)                                           │
│          │                                                               │
│          ▼                                                               │
│  ┌───────────────────────────────────────────┐                         │
│  │ ✓ Confirm Booking Complete Button         │                         │
│  │ (Validates & moves to Booked stage)       │                         │
│  └───────────────────────────────────────────┘                         │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 3: INSTALLMENT CREATION (Booked Stage)                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  Stage Changed: "Booked - Ready for Installments" ✓                    │
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────┐       │
│  │  💳 Booking Requirements Status                             │       │
│  │  ┌──────────────────────────────────────────────────────┐  │       │
│  │  │ ✓ Booking Payment: Paid ✅                           │  │       │
│  │  │ ✓ DLD Fee:         Paid ✅                           │  │       │
│  │  │ ✓ Admin Fee:       Paid ✅                           │  │       │
│  │  │                                                        │  │       │
│  │  │ Progress: [██████████] 100%                          │  │       │
│  │  │ ✓ Ready to create installment plan                   │  │       │
│  │  └──────────────────────────────────────────────────────┘  │       │
│  └─────────────────────────────────────────────────────────────┘       │
│                                                                          │
│  Three Creation Options:                                                │
│                                                                          │
│  ┌───────────────────────────────────────────┐                         │
│  │ 💰 Create Installment Plan (Automatic)    │                         │
│  │    → Uses payment schedule if configured  │                         │
│  │    → Auto-generates based on template     │                         │
│  └───────────────────────────────────────────┘                         │
│                   OR                                                     │
│  ┌───────────────────────────────────────────┐                         │
│  │ ⚡ Generate from Schedule                  │                         │
│  │    → Requires payment schedule selection  │                         │
│  │    → UAE payment plan compliance          │                         │
│  └───────────────────────────────────────────┘                         │
│                   OR                                                     │
│  ┌───────────────────────────────────────────┐                         │
│  │ 📝 Manual Installments                     │                         │
│  │    → Opens creation wizard                │                         │
│  │    → Custom amounts and dates             │                         │
│  └───────────────────────────────────────────┘                         │
│                                                                          │
│          User selects method                                            │
│          │                                                               │
│          ▼                                                               │
│  ┌───────────────────────────────────────────┐                         │
│  │ Installment Invoices Generated            │                         │
│  │ (e.g., 12 monthly installments)           │                         │
│  └───────────────────────────────────────────┘                         │
│                                                                          │
│  Smart Buttons Update:                                                  │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐            │
│  │📋 Booking│📅 Install│📄 All    │📚 Created│✅ Paid   │            │
│  │    (3)   │   (12)   │  (15)    │   (3)    │   (3)    │            │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘            │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 4: PAYMENT TRACKING (Booked Stage)                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────┐       │
│  │  💰 Payment Progress Overview Dashboard                     │       │
│  │  ┌──────────────────────────────────────────────────────┐  │       │
│  │  │ Overall Progress:    [████████░░] 80%               │  │       │
│  │  │ Paid: 400,000 / 500,000 AED                         │  │       │
│  │  │                                                        │  │       │
│  │  │ Installment Progress: [███████░░░] 70%              │  │       │
│  │  │ Outstanding: 100,000 AED                            │  │       │
│  │  └──────────────────────────────────────────────────────┘  │       │
│  │                                                              │       │
│  │  ┌───────────┬───────────┬───────────┬───────────┐        │       │
│  │  │   Total   │  Created  │   Paid    │  Pending  │        │       │
│  │  │    15     │    15     │    12     │     3     │        │       │
│  │  └───────────┴───────────┴───────────┴───────────┘        │       │
│  └─────────────────────────────────────────────────────────────┘       │
│                                                                          │
│  Invoice List View (Color-Coded):                                      │
│  ┌────────────────────────────────────────────────────────────┐       │
│  │ Seq | Type        | Date       | Amount  | Paid   | Status │       │
│  ├────────────────────────────────────────────────────────────┤       │
│  │ 1   | Booking     | 01/01/25  | 50,000  | 50,000 | Paid ✅│ 🟢   │
│  │ 2   | DLD Fee     | 01/02/25  | 80,000  | 80,000 | Paid ✅│ 🟢   │
│  │ 3   | Admin Fee   | 01/02/25  | 20,000  | 20,000 | Paid ✅│ 🟢   │
│  │ 4   | Installment | 01/03/25  | 30,000  | 30,000 | Paid ✅│ 🟢   │
│  │ 5   | Installment | 01/04/25  | 30,000  | 15,000 | Part ⚠│ 🟠   │
│  │ 6   | Installment | 01/05/25  | 30,000  |      0 | Unpd ✗│ ⚪   │
│  │ ... │             │           │         │        │        │       │
│  └────────────────────────────────────────────────────────────┘       │
│                                                                          │
│  For Each Installment Due:                                             │
│  1. Click invoice row                                                   │
│  2. Click "📋 Create Invoice" button                                   │
│  3. System generates account.move                                      │
│  4. Register payment when received                                     │
│  5. Status auto-updates to Paid ✅                                     │
│                                                                          │
│  Smart Buttons Track Progress:                                         │
│  12 → 13 → 14 → 15 (Paid count increases)                             │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 5: SALE COMPLETION (Sold Stage)                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  When all payments received (100%):                                     │
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────┐       │
│  │  💰 Payment Progress Overview                               │       │
│  │  ┌──────────────────────────────────────────────────────┐  │       │
│  │  │ Overall Progress:    [██████████] 100% ✓            │  │       │
│  │  │ Paid: 500,000 / 500,000 AED                         │  │       │
│  │  │                                                        │  │       │
│  │  │ Outstanding: 0 AED ✅                                │  │       │
│  │  └──────────────────────────────────────────────────────┘  │       │
│  └─────────────────────────────────────────────────────────────┘       │
│                                                                          │
│  Smart Buttons Final State:                                            │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐            │
│  │📋 Booking│📅 Install│📄 All    │📚 Created│✅ Paid   │            │
│  │    (3)   │   (12)   │  (15)    │   (15)   │   (15)   │ ✓         │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘            │
│                                                                          │
│  ┌───────────────────────────────────────────┐                         │
│  │  Confirm Sale Button                      │                         │
│  │  (Move to Sold stage)                     │                         │
│  └───────────────────────────────────────────┘                         │
│          │                                                               │
│          ▼                                                               │
│  Stage: "Sold" ✅                                                       │
│                                                                          │
│  Final Actions Available:                                              │
│  • Print Sales Offer Report                                            │
│  • Print SPA (Sales Purchase Agreement)                                │
│  • Lock Contract (prevent changes)                                     │
│  • Create Maintenance Requests                                         │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                         KEY BENEFITS SUMMARY                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ✅ Clear Workflow Stages       ✅ Real-time Progress Tracking         │
│  ✅ Automated Validations       ✅ Visual Payment Dashboard             │
│  ✅ Smart Invoice Management    ✅ Color-Coded Status Indicators        │
│  ✅ Guided User Experience      ✅ Comprehensive Reporting              │
│  ✅ Error Prevention            ✅ Professional SPA Compliance          │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                         SMART BUTTON LEGEND                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  📋 Booking      → Booking, DLD, Admin invoices (3 total)              │
│  📅 Installments → Property installment invoices (12+ typical)          │
│  📄 All Invoices → Complete invoice list (15+ with all fees)           │
│  📚 Created      → Invoices in accounting system (account.move)         │
│  ✅ Paid         → Fully paid invoices (increases as payments come in)  │
│  🔧 Maintenance  → Maintenance requests (available in Sold stage)       │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                         STAGE TRANSITIONS                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  Draft ──────────────────────────────────────────────────────────→ Booked
│  (Create & Pay          (Confirm Booking          (Create
│   Booking Invoices)      Complete)                 Installments)
│                                                                          │
│  Booked ──────────────────────────────────────────────────────────→ Sold
│         (Pay All              (Confirm Sale)
│          Installments)
│                                                                          │
│  Sold ───────────────────────────────────────────────────────────→ Locked
│        (Lock Contract)       (Optional - Prevents Changes)
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## 🎯 Quick Reference Matrix

| Stage | Available Buttons | Smart Buttons Active | Payment Progress |
|-------|------------------|---------------------|------------------|
| **Draft** | Create Booking Invoices, Confirm Booking Complete | 📋 Booking (3) | 0-100% (Booking) |
| **Booked** | Create Installments, Reset, Confirm Sale | 📋 Booking (3), 📅 Install (12+), 📄 All (15+) | 0-100% (Overall) |
| **Sold** | Print Reports, Lock Contract, Maintenance | All buttons active | 100% Complete ✅ |
| **Locked** | View Only | All buttons (read-only) | 100% Complete 🔒 |

---

**For detailed documentation, see:**
- [📘 Full Enhancement Guide](INVOICE_TRACKING_ENHANCEMENT.md)
- [🚀 Quick Start Guide](INVOICE_TRACKING_QUICK_START.md)
- [📊 Production Audit](RENTAL_MANAGEMENT_PRODUCTION_AUDIT.md)

---

**Version:** 3.5.0 | **Module:** rental_management | **Last Updated:** December 3, 2025
