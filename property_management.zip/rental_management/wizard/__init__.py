# -*- coding: utf-8 -*-
# Copyright 2020-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from . import contract_wizrd
from . import property_payment_wizard
from . import extend_contract_wizard
from . import property_vendor_wizard
from . import Property_maintenance_wizard
from . import booking_wizard
from . import property_sale_tenancy_xls_report
from . import landlord_tenancy_sold_xls
from . import booking_inquiry
from . import active_contract
from . import subproject_creation
from . import unit_creation
from . import aggremment_preview
