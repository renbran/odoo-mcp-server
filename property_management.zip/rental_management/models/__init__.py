# -*- coding: utf-8 -*-
# Copyright 2020-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from . import file_validation_mixin
from . import payment_schedule
from . import property_details
from . import res_partner
from . import rent_contract
from . import rent_invoice
from . import maintenance
from . import sale_contract
from . import res_config
from . import crm_lead
from . import property_region
from . import property_project
from . import property_sub_project
from . import rent_bill
from . import ir_action
from . import ir_ui_view
from . import account_move
