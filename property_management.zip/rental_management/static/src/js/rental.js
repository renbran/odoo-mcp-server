/** @odoo-module **/
// Rental Management - Main JavaScript Module
console.log("[rental_management] Main module loaded");
export default {};
