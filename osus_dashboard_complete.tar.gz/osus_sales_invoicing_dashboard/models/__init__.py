# -*- coding: utf-8 -*-
from . import sales_invoicing_dashboard
from . import sale_order
